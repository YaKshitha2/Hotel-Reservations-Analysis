-- Sprint 3: Basic analysis/Data Exploration 
-- 1.Total no.of guests
select count(*) as total_guests from guests;

-- 2.Total no.of bokkings
select count(*) as total_bookings from bookings;

-- 3.Total no.of stays
select count(*) as total_stays from stays;

-- 4.What are the different room types available
select distinct room_type from rooms;

-- 5.Number of active staff members
select count(*) as active_staff from staff where is_active  = 'Yes';

-- 6.Different Booking channels
select distinct booking_channel from bookings;

-- 7.Total booking amount
select sum(total_amount) as total_amount from bookings;

-- 8. Average nights booked
select avg(nights_booked) as average_nights_booked
from bookings;