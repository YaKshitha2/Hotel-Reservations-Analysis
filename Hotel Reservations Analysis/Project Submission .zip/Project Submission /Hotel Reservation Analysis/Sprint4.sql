-- Sprint 4 - Objective-Based Analysis
-- 4.1- Understand Booking Demand
----------------------------------------------------------------------
-- 1.Which hotels receive the highest number of bookings?
select hotel_id, count(*) as total_bookings
from bookings
group by hotel_id
order by total_bookings desc;

-- 2.Which booking channel generates the most bookings?
select booking_channel, count(*) as total_bookings
from bookings
group by booking_channel
order by total_bookings desc;

-- 3.Which room type is booked most frequently?
select room_type_requested, count(*) as total_bookings
from bookings
group by room_type_requested
order by total_bookings desc;

-- 4.How does booking volume change over time?
select booking_date, count(*) as total_bookings
from bookings
group by booking_date
order by booking_date;

-- 5.Which booking channel generates the highest total booking amount?
select booking_channel, sum(total_amount) as total_amount
from bookings
group by booking_channel
order by total_amount desc;
-------------------------------------------------------------------------
-- 4.2 - Understand Guest Booking Behaviour
-- 1.Which guests make the highest number of bookings?
select guest_id, count(*) as total_bookings
from bookings
group by guest_id
order by total_bookings desc;

-- 2.Which guests have the highest total booking amount?
select guest_id, sum(total_amount) as total_booking_amount
from bookings
group by guest_id
order by total_booking_amount desc;

-- 3.Which hotels have the highest guest booking activity?
select hotel_id, count(*) as total_bookings
from bookings
group by hotel_id
order by total_bookings desc;

-- 4.How does booking activity change over time?
select booking_date,
       COUNT(*) as total_bookings,
       SUM(total_amount) as total_revenue
from bookings
group by booking_date
order by booking_date;
--------------------------------------------------------------------
-- 4.3 - Evaluate stay performance
-- 1. compare stay outcomes across hotels
select b.hotel_id,
       s.status,
       count(*) as total_stays
from bookings b
join stays s
on b.booking_id = s.booking_id
group by b.hotel_id, s.status
order by b.hotel_id, total_stays desc;


-- 2. examine stay duration
select s.stay_id,
       s.check_in_date,
       s.check_out_date,
       datediff(s.check_out_date, s.check_in_date) as stay_duration
from stays s
where s.check_in_date is not null
and s.check_out_date is not null
order by stay_duration desc;


-- 3. compare stay outcomes by status
select status,
       count(*) as total_stays
from stays
group by status
order by total_stays desc;


-- 4. identify hotels with higher booking activity
select b.hotel_id,
       count(*) as total_bookings
from bookings b
group by b.hotel_id
order by total_bookings desc;


-- 5. identify hotels with poorer stay outcomes
select b.hotel_id,
       s.status,
       count(*) as total_stays
from bookings b
join stays s
on b.booking_id = s.booking_id
where s.status in ('no-show', 'cancelled')
group by b.hotel_id, s.status
order by total_stays desc;
 --------------------------------------------------------------------
-- 4.4.- Understand Staff And Room Performance
-- 1 stays handled by each staff member
select staff_id,
       count(*) as total_stays
from stays
group by staff_id
order by total_stays desc;


-- .2 staff performance across stay outcomes
select staff_id,
       status,
       count(*) as total_stays
from stays
group by staff_id, status
order by staff_id, total_stays desc;


-- 3. average stay duration by staff
select staff_id,
       avg(datediff(check_out_date, check_in_date)) as average_stay_duration
from stays
group by staff_id
order by average_stay_duration desc;


-- 4 .room usage by room type
select r.room_type,
       count(*) as total_stays
from stays s
join rooms r
on s.room_id = r.room_id
group by r.room_type
order by total_stays desc;


-- 5. stay performance across rooms
select room_id,
       status,
       count(*) as total_stays
from stays
group by room_id, status
order by room_id, total_stays desc;


-- 6. average stay duration by room
select room_id,
       avg(datediff(check_out_date, check_in_date)) as average_stay_duration
from stays
group by room_id
order by average_stay_duration desc;
--------------------------------------------------------------------
-- 4.5 Identify Booking and Stay Problems
-- 1 examine which bookings resulted in cancellations or no-shows
select b.booking_id,
       b.hotel_id,
       s.status
from bookings b
join stays s
on b.booking_id = s.booking_id
where s.status in ('cancelled', 'no-show');

-- 2. identify common stay statuses and problem patterns
select status,
       count(*) as total_stays
from stays
group by status
order by total_stays desc;

-- 3. examine whether certain hotels experience more booking problems
select b.hotel_id,
       count(*) as problem_bookings
from bookings b
join stays s
on b.booking_id = s.booking_id
where s.status in ('cancelled', 'no-show')
group by b.hotel_id
order by problem_bookings desc;
