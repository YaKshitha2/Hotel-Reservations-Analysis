-- Sprint 2- Database setup
-- 2.1 - Design the Database from the ER Diagram
-- =========================
CREATE DATABASE hotel_reservation;
USE hotel_reservation;

CREATE TABLE guests (
    guest_id VARCHAR(20) PRIMARY KEY,
    guest_name VARCHAR(100),
    city VARCHAR(50),
    guest_type VARCHAR(20),
    preferred_room_type VARCHAR(20),
    loyalty_tier VARCHAR(20) not null,
    account_since date
);
ALTER TABLE guests
MODIFY account_since VARCHAR(20);

select * from guests;

CREATE TABLE hotels (
    hotel_id VARCHAR(20) PRIMARY KEY,
    hotel_name VARCHAR(100),
    city VARCHAR(50),
    star_rating INT,
    total_rooms INT,
    opened_date DATE
);
ALTER TABLE hotels
MODIFY opened_date VARCHAR(20);

select * from hotels;

CREATE TABLE rooms (
    room_id VARCHAR(20) PRIMARY KEY,
    hotel_id VARCHAR(20),
    room_type VARCHAR(20),
    floor_number INT,
    max_occupancy INT,
    price_per_night DECIMAL(10,2),
    is_active VARCHAR(3),

    FOREIGN KEY (hotel_id)
        REFERENCES hotels(hotel_id)
);
select * from rooms;

CREATE TABLE bookings (
    booking_id VARCHAR(20) PRIMARY KEY,
    guest_id VARCHAR(20),
    hotel_id VARCHAR(20),
    booking_date DATE,
    room_type_requested VARCHAR(20),
    booking_channel VARCHAR(30),
    nights_booked INT,
    total_amount DECIMAL(12,2),

    FOREIGN KEY (guest_id)
        REFERENCES guests(guest_id),

    FOREIGN KEY (hotel_id)
        REFERENCES hotels(hotel_id)
);
ALTER TABLE bookings
MODIFY booking_date VARCHAR(20);
select * from bookings;

CREATE TABLE staff (
    staff_id VARCHAR(20) PRIMARY KEY,
    staff_name VARCHAR(100),
    hire_date DATE,
    rating DECIMAL(3,2),
    department VARCHAR(30),
    is_active VARCHAR(3)
);
ALTER TABLE staff
MODIFY hire_date VARCHAR(20);
select * from staff;

CREATE TABLE stays (
    stay_id VARCHAR(20) PRIMARY KEY,
    booking_id VARCHAR(20),
    room_id VARCHAR(20),
    staff_id VARCHAR(20),
    check_in_date DATE,
    check_out_date DATE,
    status VARCHAR(20),
    nights_stayed INT,
    service_requests INT,
    stay_duration_hrs INT,

    FOREIGN KEY (booking_id)
        REFERENCES bookings(booking_id),

    FOREIGN KEY (room_id)
        REFERENCES rooms(room_id),

    FOREIGN KEY (staff_id)
        REFERENCES staff(staff_id)
);
DROP TABLE IF EXISTS stays;
ALTER TABLE stays
MODIFY check_in_date VARCHAR(20);


ALTER TABLE stays
MODIFY check_out_date VARCHAR(20);

select * from stays;
-----------------------------------------------------
-- 2.2 Data Import
-- After importing Then verify:

SELECT COUNT(*) FROM guests;

SELECT COUNT(*) FROM hotels;

SELECT COUNT(*) FROM rooms;

SELECT COUNT(*) FROM bookings;

SELECT COUNT(*) FROM stays;

SELECT COUNT(*) FROM staff;

